# SCHOOL RESULT ANALYTICS DASHBOARD

## Classes
- Class XII – Commerce: English, Accountancy, Business Studies, Economics, Informatics Practices
- Class XI – Science: English, Physics, Chemistry, Mathematics, Biology

## Files
- app.py: Streamlit dashboard
- data/class_xii_commerce.csv: empty Commerce data template
- data/class_xi_science.csv: empty Science data template
- requirements.txt: Python libraries

## CSV format
Keep the column names exactly as shown in the two CSV templates. Each row represents one student. Marks must be numeric and between 0 and 100. The app currently assumes all five subjects are out of 100.

## Update GitHub
Upload/replace app.py, requirements.txt, and the complete data folder. Commit the changes. Streamlit Community Cloud should redeploy automatically.

## Privacy
Your repository was initially public. Change it to Private before adding real student names and marks (GitHub repository Settings > General > Danger Zone > Change repository visibility). Follow school policy. The included CSV templates are empty.

The below-40 support indicator is a demonstration rule only, not an official CBSE pass/fail decision.
