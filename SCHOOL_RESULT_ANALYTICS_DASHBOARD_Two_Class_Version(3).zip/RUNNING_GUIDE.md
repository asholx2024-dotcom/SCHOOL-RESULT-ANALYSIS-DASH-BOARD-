# Two-class dashboard update guide

1. Extract this ZIP.
2. In your GitHub repository, upload/replace app.py and requirements.txt.
3. Upload the entire data folder with BOTH CSV files inside it.
4. Commit the changes.
5. Open Streamlit Community Cloud and wait for redeployment; refresh the app.
6. Select Class XII – Commerce or Class XI – Science from the sidebar.
7. Edit the relevant CSV template in GitHub and commit to update the student data.

Privacy: change the GitHub repository to Private before adding real student names/marks. Check school policy before storing student data in cloud services.
